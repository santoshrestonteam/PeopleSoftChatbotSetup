'use strict';

   // static js components for core library

module.exports = {
   // 'core.util.parseDate': require('.core-util/parseDate'),  
  // 'core.util.msgCatInit' : require('./core-util/messageCatalogInit') 
};
