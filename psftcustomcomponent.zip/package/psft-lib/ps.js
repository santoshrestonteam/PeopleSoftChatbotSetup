const config = require('./config/config');

const Environments = config.lib.environments();
const Services = config.lib.services();

/**
 * Peoplesoft service wrapper.
 * @class
 * @param {string} in_env Environment Name
 * @param {string} in_svc Service Name
 */
function Service(in_env, in_svc) {
    var that = this;
    var envName = in_env,
        svcName = in_svc;

    /**
     * Execute the service.
     * @memberOf Service
     * @param {object} payload Payload to be passed to the service.
     * @param {object} conversation (Optional) IBCS Conversation SDK
     */
    
    that.execute = async function(payload, conversation=null) {
        return await Services.execute(Environments.get(envName, conversation), svcName, payload);
    };

    return that;
}

/**
 * Peoplesoft environment wrapper.
 * @class
 * @param {string} in_env Environment Name
 */
function Environment(in_env) {
    var that = this;
    var envName = in_env;

    /**
     * Create a service wrapper object for the service in_svc.
     * @param {string} in_svc Service Name
     * @memberOf Environment
     */
    that.get = function(in_svc) {
        return new Service(envName, in_svc);
    };

    /**
     * Return an array of service metadata under the environment.
     */
    that.services = function() {
        return Services.get(envName);
    };

    return that;
}

/**
 * @class
 * @name ps
 * @example 
 *  var PSFT = new ps();
 *  await PSFT.ready;
 *  PSFT.get("HCM").get("TestService1").execute({myargument: "test"}, conversation);
 * @example 
 *  // Preferred syntax. The service metadata for this syntax is cached.
 *  PSFT.HCM.TestService1.execute({myargument: "test"}, conversation);    // alternate short syntax
 */
function buildps() {
    var ps = this;

    var buildServices =  async function() {
        for(var envName in Environments.get()) {
            if(["get"].includes(envName)) throw "Invalid Environment Name: " + envName; // Check for disallowed environment names.

            // Create a property under ps for each environment
            ps[envName] = new Environment(envName);
            
            // create a property under the environment, for each service provided by that environment
            var services = await ps[envName].services();

            for(var service of services) {
                ps[envName][service.IDForServiceURL] = new Service(envName, service.IDForServiceURL);
            }
                    
        }
        return ps;
    };   
    
    /**
     * This promise is resolved when the ps object is built.
     * @example await ps.ready; // in an async function
     * @memberOf ps
     */
    ps.ready = buildServices();

    /**
     * Get an Environment wrapper.
     * @param {string} envName 
     * @memberOf ps
     */
    ps.get = function(envName) {
        return new Environment(envName);
    };
    return ps;
}


module.exports = buildps;
