

var out = {
    "environments": require("./environments.json"),
    "libpaths": {
        "session": "../lib/session",
        "environments": "../lib/environments",
        "services": "../lib/services",
        "utilities": "../lib/utilities"
    },
    "lib": {
        "session": () => require(out.libpaths.session),
        "environments": () => require(out.libpaths.environments),
        "services": () => require(out.libpaths.services),
        "utilities": () => require(out.libpaths.utilities),
    },
    "require": (libpath) => require(libpath),
    "ready": true
}

module.exports = out;
