"use strict";

var test_config = require("./test_config.json");


var config = require(test_config.config_path);
var Session = config.lib.session();

var conversation = {    // Stub for IBCS conversation SDK
    session: "",
    variable: function(varname, value = undefined) {
        if(varname == "profile.token")
            return "PSToken";

        if(value !== undefined)
            this.session = value;
        return this.session;
    }
};

describe("Session", function() {
    it("token() returns a the PSToken", function() {
        var session = new Session(conversation);

        expect(session.token()).toBe("PSToken");
    });

    it("set('key', 'value') sets the value of 'key' to 'value' for all types.", function() {
        var session = new Session(conversation);

        expect(session.get("key")).toBeUndefined();
        expect(session.set("key", "value")).toBe("value");
        expect(session.get("key")).toBe("value");
    });
});
