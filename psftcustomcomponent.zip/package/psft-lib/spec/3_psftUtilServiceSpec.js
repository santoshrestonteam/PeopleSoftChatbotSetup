"use strict";

var test_config = require("./test_config.json");

var config = require(test_config.config_path);
var services = config.lib.services();

describe("Services", function() {

    it("count() returns the number of services", async function() {
        // Count should return a valid number for HCM
        expect(await services.count("HCM")).toBeGreaterThanOrEqual(1);
    });

    it("count('x') returns 0 because the environment doesn't exist", async function() {
        
        // Count should return 0 for an invalid environment.
        expect(await services.count("X")).toBe(0);

    });

    it("get() returns an array of available services", async function() {
        // A valid environemnt shoud return count() services.
        expect((await services.get("HCM")).length).toBe(await services.count("HCM"));

        // An invalid environment should return 0 services.
        expect((await services.get("X")).length).toBe(0);
    });

    it("get('env', 'test.core.serviceframework') returns a single service", async function() {
        expect((await services.get("HCM", "test.core.serviceframework")).IDForServiceURL).toEqual("test.core.serviceframework");
    });

    
    it("execute() executes a service", async function() {
        // Executing a valid service with valid parameters should succeed
        var response = await services.execute("HCM", "test.core.serviceframework", {"inputparam": "Test String"});
        expect(response).toEqual({ "outputparam": "Test String" });

        // Executing a valid service with invalid parameters should be rejected
        // var x = await services.execute("HCM", "TestService2", {"BADPARAM": "Test String"});
        // console.log(x);
        // THIS SHOULD FAIL, BUT IT IS not FAILING!!!.

        // Executing an invalid service should be rejected
        var invalidService = false;
        services.execute("HCM", "TestServiceDOESNTEXIST", {}).catch(() => {
            invalidService = true;
        }).then(() => {
            expect(invalidService).toBe(true);
        });


        // Executing a service on an invalid environment should be rejected.
        var badEnvironment = false;
        services.execute("X", "TestService", {}).catch(() => {
            badEnvironment = true;
        }).then(() => {
            expect(badEnvironment).toBe(true);
        });

    });
});
