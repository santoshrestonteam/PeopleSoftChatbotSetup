"use strict";

describe("Utilities", function() {

    var test_config = require("./test_config.json");

    var config = require(test_config.config_path);
    var utilities = config.lib.utilities();

    var jsDate = new Date("2018-11-22");

    it("parseJSDateToPS returns undefined for invalid JS Date input", function () {

        expect(utilities.parseJSDateToPS("random")).toBeUndefined();
    });

    it("parsePSDateToJS returns undefined for invalid PS Date input", function () {

        expect(utilities.parsePSDateToJS("random")).toBeUndefined();
    });

    it("parseJSDateToPS returns a valid object for valid JS Date input", function () {

        expect(utilities.parseJSDateToPS(jsDate)).toEqual("2018-11-22");;
    });

    it("parsePSDateToJS returns a valid object for valid PS Date Input", function () {

        var jsDateObject = utilities.parsePSDateToJS("2018-11-22");
        expect(jsDateObject.getTime()).toEqual(jsDate.getTime());
    });

});